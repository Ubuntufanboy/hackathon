import math
class Regression:
    def __init__(self):
         self.regr = []
         self.lowestVal = 10000
         self.index = -1
         self.dic = {0: "a", 1:"b", 2: "c", 3: "d", 4: "e", 5: "f", 6: "g", 7:"h", 8:"i",9:"k", 10:"l", 11:"m", 12:"n", 13:"o", 14:"p", 15:"q", 16:"r", 17:"s", 18:"t", 19:"u", 20:"v", 21:"w", 22:"x", 23:"y", 24:"z"}

    def getLine(self, numLine, numParam, fName):
        with open(fName) as f:
            lines = f.readlines()
            return lines[numLine].split(",")[numParam]
    def compareFile(self, currentVal, fName):
        for i in range(20):
            average = 0
            for j in range(5):
                diff = abs(currentVal[j]-float(self.getLine(i,j, fName)))
                average += diff
            self.regr.append(average/5)
    def compareLetters(self, currentVal):
        self.regr = []
        for i in range(24):
            self.compareFile(currentVal, (self.dic[i]+".txt"))
            #print(self.dic[i])
    def findMatch(self):
        self.lowestVal = 10000
        for i in range(480):
            if self.regr[i]<self.lowestVal:
                # print("hi")
                self.lowestVal = self.regr[i]
                self.index = i
        #print(self.index)
    def findMatchFile(self):
        fileIndex = self.index//20
        print(fileIndex)
        print(self.dic[fileIndex])

            
            
            

foo = Regression()
foo.compareLetters([145.11374848717816,71.00704190430693,77.62087348130012,84.59905436823747,71.30918594402827])
print(len(foo.regr))
foo.findMatch()
print(foo.index)
foo.findMatchFile()